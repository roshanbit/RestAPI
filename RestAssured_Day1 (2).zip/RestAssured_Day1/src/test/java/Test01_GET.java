import org.testng.Assert;
import org.testng.annotations.Test;


import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;
 

public class Test01_GET {
	
	@Test
	void test01()
	{
		/*
Informational responses (100�199)
Successful responses (200�299)
Redirection messages (300�399)
Client error responses (400�499)
Server error responses (500�599)

below two dependency required for RestAssued API Testing

testng 7.4.0 
rest-assured 4.4.0

		install json-formatter extension in your browser-----> to see response in JSON format 
		
		*/
		
		
		//Response response = RestAssured.get("https://reqres.in/api/users?page=2"); 
		//when restassured class is imported with static keyword then Restassured is not required
		//import io.restassured.RestAssured;
		Response response = get("https://reqres.in/api/users?page=2");//Response is interface, restassured is class, get,given(),then() are method
		System.out.println(response.asString());   //ctrl+i (to format Json/XML)
		System.out.println(response.getBody().asString());
		System.out.println(response.getStatusCode());
		System.out.println(response.getHeader("Content-Type"));
		System.out.println(response.getTime());
		System.out.println(response);
		int satuscode= response.getStatusCode();
		System.out.println(satuscode); //200
		Assert.assertEquals(satuscode, 200); // if Assert.assertEquals(satuscode, 201) then this method will fail
				
	}
	
	@Test
	void test02()
	{
		given().
			param("Key", "values").
			header("Content-Type","application/json").
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			get("https://reqres.in/api/users?page=2").  // ? :Its name is query string. After the question mark you can pass key-value pairs and use them server-side.
		then().
			statusCode(200).
			body("data.id[1]", equalTo(8)).     //if we want to validate body--->import import static org.hamcrest.Matchers.*;			
			//Matchers is class	
			
			body("data.first_name", hasItems("Michael","Lindsay")).  //hasItem for one, hasItems for multiple/one
			
			log().all();
			
		
	}

@Test
void test03()
{
	given()
		.get("https://reqres.in/api/users?page=2").
	then()
	.statusCode(200);
		// if statusCode(201)
		//Expected status code <201> but was <200>.
	
}

}
