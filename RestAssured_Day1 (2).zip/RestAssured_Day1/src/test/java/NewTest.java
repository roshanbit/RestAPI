import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewTest {

	public static void main(String[] args) throws InterruptedException {

		
		//System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@title='Search']")).sendKeys("covid status");
		driver.findElement(By.xpath("(//input[@aria-label='Google Search'])[2]")).click();
		Thread.sleep(3000);
		WebElement wb = driver.findElement(By.xpath("(//span[contains(text(),'New cases')])[3]"));
		
		if(wb.isDisplayed())
		{
			System.out.println("Search Result found");
		}
		else
		{
			System.out.println("Search Result NOT found");
		}

	

	}

}
